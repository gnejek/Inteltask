// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vquadra_top.h for the primary calling header

#include "Vquadra_top__pch.h"
#include "Vquadra_top___024root.h"

VlCoroutine Vquadra_top___024root___eval_initial__TOP__Vtiming__0(Vquadra_top___024root* vlSelf);
VlCoroutine Vquadra_top___024root___eval_initial__TOP__Vtiming__1(Vquadra_top___024root* vlSelf);
VlCoroutine Vquadra_top___024root___eval_initial__TOP__Vtiming__2(Vquadra_top___024root* vlSelf);

void Vquadra_top___024root___eval_initial(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_initial\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vquadra_top___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vquadra_top___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    Vquadra_top___024root___eval_initial__TOP__Vtiming__2(vlSelf);
}

VL_INLINE_OPT VlCoroutine Vquadra_top___024root___eval_initial__TOP__Vtiming__0(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_initial__TOP__Vtiming__0\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.quadra_tb__DOT__clk = 0U;
    while (1U) {
        co_await vlSelfRef.__VdlySched.delay(0x1f4ULL, 
                                             nullptr, 
                                             "quadra_tb.vs", 
                                             55);
        vlSelfRef.quadra_tb__DOT__clk = (1U & (~ (IData)(vlSelfRef.quadra_tb__DOT__clk)));
    }
}

VL_INLINE_OPT VlCoroutine Vquadra_top___024root___eval_initial__TOP__Vtiming__1(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_initial__TOP__Vtiming__1\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         61);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         61);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         63);
}

VL_INLINE_OPT VlCoroutine Vquadra_top___024root___eval_initial__TOP__Vtiming__2(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_initial__TOP__Vtiming__2\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*23:0*/ quadra_tb__DOT__x;
    quadra_tb__DOT__x = 0;
    // Body
    VL_WRITEF_NX("Started quadra_tb ...\n",0);
    quadra_tb__DOT__x = 0U;
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         76);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         76);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         76);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         76);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         76);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         76);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         76);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         76);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         76);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         76);
    quadra_tb__DOT__x = 0x7fffffU;
    VL_WRITEF_NX("x = 0x%08x\n",0,24,quadra_tb__DOT__x);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         83);
    quadra_tb__DOT__x = 0U;
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         88);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         88);
    VL_WRITEF_NX("y = 0x00000000000\n",0);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         92);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         92);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         92);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         92);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         92);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         92);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         92);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         92);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         92);
    co_await vlSelfRef.__VtrigSched_ha75bd6de__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge quadra_tb.clk)", 
                                                         "quadra_tb.vs", 
                                                         92);
    VL_WRITEF_NX("Simulation finished.\n",0);
    VL_FINISH_MT("quadra_tb.vs", 96, "");
}

void Vquadra_top___024root___eval_act(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_act\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

void Vquadra_top___024root___eval_nba(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_nba\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

void Vquadra_top___024root___timing_resume(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___timing_resume\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((2ULL & vlSelfRef.__VactTriggered.word(0U))) {
        vlSelfRef.__VtrigSched_ha75bd6de__0.resume(
                                                   "@(posedge quadra_tb.clk)");
    }
    if ((1ULL & vlSelfRef.__VactTriggered.word(0U))) {
        vlSelfRef.__VdlySched.resume();
    }
}

void Vquadra_top___024root___timing_commit(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___timing_commit\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((! (2ULL & vlSelfRef.__VactTriggered.word(0U)))) {
        vlSelfRef.__VtrigSched_ha75bd6de__0.commit(
                                                   "@(posedge quadra_tb.clk)");
    }
}

void Vquadra_top___024root___eval_triggers__act(Vquadra_top___024root* vlSelf);

bool Vquadra_top___024root___eval_phase__act(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_phase__act\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlTriggerVec<2> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vquadra_top___024root___eval_triggers__act(vlSelf);
    Vquadra_top___024root___timing_commit(vlSelf);
    __VactExecute = vlSelfRef.__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelfRef.__VactTriggered, vlSelfRef.__VnbaTriggered);
        vlSelfRef.__VnbaTriggered.thisOr(vlSelfRef.__VactTriggered);
        Vquadra_top___024root___timing_resume(vlSelf);
        Vquadra_top___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vquadra_top___024root___eval_phase__nba(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_phase__nba\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelfRef.__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vquadra_top___024root___eval_nba(vlSelf);
        vlSelfRef.__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vquadra_top___024root___dump_triggers__nba(Vquadra_top___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vquadra_top___024root___dump_triggers__act(Vquadra_top___024root* vlSelf);
#endif  // VL_DEBUG

void Vquadra_top___024root___eval(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY(((0x64U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            Vquadra_top___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("quadra_tb.vs", 15, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelfRef.__VactIterCount = 0U;
        vlSelfRef.__VactContinue = 1U;
        while (vlSelfRef.__VactContinue) {
            if (VL_UNLIKELY(((0x64U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                Vquadra_top___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("quadra_tb.vs", 15, "", "Active region did not converge.");
            }
            vlSelfRef.__VactIterCount = ((IData)(1U) 
                                         + vlSelfRef.__VactIterCount);
            vlSelfRef.__VactContinue = 0U;
            if (Vquadra_top___024root___eval_phase__act(vlSelf)) {
                vlSelfRef.__VactContinue = 1U;
            }
        }
        if (Vquadra_top___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vquadra_top___024root___eval_debug_assertions(Vquadra_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vquadra_top___024root___eval_debug_assertions\n"); );
    Vquadra_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
